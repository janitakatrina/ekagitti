public class Controller {

    private Model model;
    private View view;

    public Controller(Model model, View frame) {
        this.model = model;
        this.view = frame;
    }

    public void Randomize() {
       view.setRandomNumber(model.Randomize());
    }
}