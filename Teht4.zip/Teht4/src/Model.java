public class Model {
    public int Randomize() {
        return 1+ (int)(Math.random()*6);
    }
}